<template>
	<div class="article">
		<div class="article_left">
			<h1 class="article_title">王嘉尔、陈伟霆、华晨宇…2020年，爱豆们都在推潮牌</h1>
			<p class="article_p">
				<span><router-link to="/home/first">潮流指南频道</router-link></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;发布者 ： <span>S7even</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;时间：2020-11-04 16:32
			</p>
			<div class="article_pic">
					<strong>今年，这些爱豆做起潮牌生意……</strong>
          <p>
          如果把爱豆的公众形象视为IP，那么潮牌已成为这个IP最常见，也是最重要的组成部分和表达方式。今年，这些爱豆凭借自己对时尚的解读，纷纷做起潮牌事业，其自带的光环，让品牌一推出就成为了潮牌市场中被关注的热点。
				</p>
				<p style="text-align:center;margin:10px 0">
					<img :src="'../static/images/n13.jpg'" alt="pic"/>
				</p>
				<strong>1、王嘉尔：TEAM WANG</strong>
				<p>
					TEAM WANG是王嘉尔花了三年时间准备的个人潮牌，今年7月18日，其***系列“THE ORIGINAL”正式发售。

					担任品牌创意总监和设计师的王嘉尔对外表示：“我希望 TEAM WANG 传达的一种精神是你要很懂你自己，知道自己要什么。”因此，在“THE ORIGINAL”系列设计里，王嘉尔弱化了模特的存在感，无论谁在穿，他们现实中的身份和标签都不重要。此外，产品以黑色为主色调，没有繁冗复杂的装饰，极简实用的基础款是其设计的主要风格。

					此外，在“THE ORIGINAL”正式发售的同一天，TEAM WANG的线下实体店也在上海静安嘉里中心正式开幕，这是为期两个月的快闪店。门店跟品牌和调性一致，以黑白为主色调，纯白装潢搭配富有质感的黑色雕塑，每一件装饰上都印有Team Wang的字样。门店内，一个货架都没有设置，“THE ORIGINAL”系列化身为展品，打破了大家对于潮牌店的刻板印象。因此，开业高峰时期，要进店需要排队六个小时
				</p>
				<p style="text-align:center;margin:10px 0">
					<img :src="'../static/images/n14.jpg'" alt="pic"/>
				</p>
        <strong>2、陈伟霆：CANOTWAIT_™?</strong>
				<p>
					早在2018年，陈伟霆已经推出过自己的潮流品牌WILLIAMISM。不过，后面因为种种原因中途夭折。

					今年4月，在演艺事业全面开花之际，他也推出个人全新潮牌CANOTWAIT_™?。品牌名字意为“无须等待”、“迫不及待”，其设计出发点源于陈伟霆对于艺术与街头文化的热爱与思考。他认为，人类的情感本身就是一种艺术，亦是很多文化与艺术作品根深蒂固的本源。

					CANOTWAIT_™?***系列和夏季特别限定系列“食蝇草”在得到app发布，前者上线3小时即全部售罄;后者深受好评，不少时尚自媒体，以陈伟霆这套限定款服饰作为夏季潮流青年的穿搭指导。品牌也因此获得了非粉丝以外的消费群体认可，成功完成了从“粉丝向”到“大众向”的转向。

					而在今年10月5日至10月11日，CANOTWAIT_™?在上海TX淮海NNERSECT旗舰店开设了全球***AW20新品概念快闪店及互动展「CANOTWAIT TO SMILE」。
				</p>
				<p style="text-align:center;margin:10px 0">
					<img :src="'../static/images/n15.jpg'" alt="pic"/>
				</p>
         <strong>3、华晨宇：BORN TO LOVE</strong>
				<p>
					今年4月，华晨宇的火星空间站MARS***在微博营业，并公布了华晨宇的个人概念IP——BORN TO LOVE。这只被粉丝称为“火星鼠”的虚拟生物，是基于华晨宇的形象，再结合老鼠、火星、生日、爱心等元素进行创作的。

					9月25日，BORN TO LOVE正式***与艺术家联名款潮玩公仔，商品上架后1秒内售罄。该款公仔是***艺术家韩美林携手潮流主理人华晨宇，与@火星空间站MARS 共同打造的作品。其定价899元，目前已经是停售状态。在微博搜索“华晨宇 火星鼠”，大部分都是华晨宇粉丝的晒单分享。
				</p>
				<p style="text-align:center;margin:10px 0">
					<img :src="'../static/images/n16.jpg'" alt="pic"/>
				</p>
				<p>
				一方面，娱乐圈与时尚界自带联动性，明星同款穿搭一直以来都会带动粉丝的热议、追捧甚至模仿;另一方面，在质量堪忧的快时尚和价格昂贵的奢侈品之间，潮牌以价格中立、设计小众、限量发行和较高的品质占了上风。

					可以预见的是，明星扎堆做潮牌趋势，未来仍将延续。
				</p>
			</div>
		</div>
		<div class="article_right">
			<div class="tags">
				<p class="hot">今日头条</p><p class="more">更多</p>
			</div>
			<ul class="tag">
				<li class="tag_li">
					<div class="tag_li_left">
						<router-link to="/news">陈冠希、小红书、微博正在杀死中国潮牌鼻祖，邱淑贞家族巨亏7亿</router-link>
						<p>昔日国产潮牌“鼻祖”、女神邱淑贞、张曼玉加持的I.T，已经陷入经营危机。</p>
					</div>
					<div class="tag_li_right">
						<img :src="'../static/images/n17.jpeg'" alt="tag"/>
					</div>
				</li>
				<li class="tag_li">
					<div class="tag_li_left">
						<router-link to="/news">与年轻人交流这事儿难吗？至少OFF-WHITE做到了</router-link>
						<p>这个才成立短短5年的品牌，凭什么如今风头无两？</p>
					</div>
					<div class="tag_li_right">
						<img :src="'../static/images/n18.jpg'" alt="tag"/>
					</div>
				</li>
				<li class="tag_li">
					<div class="tag_li_left">
						<router-link to="/news">这！就是街舞背后的潮牌生意</router-link>
						<p>在中国，跳街舞养不活自己是大众的普遍认知，但就是这样一群人，让优酷和爱奇艺相继砸了超过3亿的资金，请他们走到大众面前。</p>
					</div>
					<div class="tag_li_right">
						<img :src="'../static/images/n19.jpg'" alt="tag"/>
					</div>
				</li>
				<li class="tag_li">
					<div class="tag_li_left">
						<router-link to="/news">中国潮男在东北</router-link>
						<p>东北男生穿貂么？可别再把这句调侃当真了。</p>
					</div>
					<div class="tag_li_right">
						<img :src="'../static/images/n20.jpg'" alt="tag"/>
					</div>
				</li>
				<li class="tag_li">
					<div class="tag_li_left">
						<router-link to="/news">【一周商业重磅】微信公号要推独立APP 家乐福在中国面临出售命运</router-link>
						<p>前行政总裁寿柏年清仓绿城全部股份；家乐福中国可能被卖掉；日本正面临鳗鱼危机；张小龙透露微信公众号要做独立APP；潮牌扎堆的上海长乐路拆改了；飞机上可以使用手机了。以...</p>
					</div>
					<div class="tag_li_right">
						<img :src="'../static/images/n21.jpg'" alt="tag"/>
					</div>
				</li>
				<li class="tag_li">
					<div class="tag_li_left">
						<router-link to="/news">花了三年时间泰国的一间车库成功变身潮流博物馆</router-link>
						<p>喜欢Be@rbrick积木熊的潮人们，泰国的这家“私人博物馆”你们一定不想错过。</p>
					</div>
					<div class="tag_li_right">
						<img :src="'../static/images/n22.jpg'" alt="tag"/>
					</div>
				</li>
			</ul>
		</div>
	</div>
</template>
<script type="text/javascript">
	export default {

	}
</script>
<style scoped>
	.article{width: 990px;margin: 0 auto}
	.article:after{display: block;content:"";width: 0;height: 0;clear: both}
	.article_left{width: 670px;float:left;}
	.article_title{text-align: center;padding: 10px 0;margin-bottom: 8px;border-bottom: 1px solid #999;font-weight:bold;font-size:24px;color:#111;}
	.article_p{color:#999;font-size:12px;margin-bottom: 8px;}
	.article_p span{color:#33cccc;}
	.article_p a{color:#33cccc;}
	.article_p a:hover{text-decoration:underline;}
	.article_pic img{width: 600px;height: auto;border: none}
	.article_pic p{word-wrap: break-word;word-break: break-all;color: #111;line-height: 28px;font-size: 14px}
	.article_pic strong{margin: 30px 0;display: block}
	.article_right{width: 235px;float:right;}
	.tags{margin-top: 20px;font-size: 12px;border-bottom: 1px solid #ccc}
	.tags:after{display: block;content:"";width: 0;height: 0;clear: both}
	.hot{float:left;}
	.more{float:right;}
	.tag_li{padding:15px 0;border-bottom: 1px solid #ccc;}
	.tag_li:after{display: block;content:"";width: 0;height: 0;clear: both}
	.tag_li_left{float:left;width: 160px}
	.tag_li_left a{overflow: hidden;text-overflow: ellipsis;display: inline-block;height: 25px;line-height: 25px;font-size: 13px;color:#111;width: 160px;white-space: nowrap;font-weight: normal;}
	.tag_li_left p{height: 32px;font-size:12px;line-height: 16px;overflow: hidden;text-overflow: ellipsis;color:#999;}
	.tag_li_right{float:right;width: 68px}
	.tag_li_right img{max-width: 68px;height: auto}
</style>
