/*
* @Author: Administrator
* @Date:   2017-01-23 12:30:55
* @Last Modified by:   Administrator
* @Last Modified time: 2017-03-02 20:00:52
*/

import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const state={
	loginway:'',
	show:'home',
	clientheight:0,
	clientwidth:0,
	// footItems:[
	// 	{title:'ABOUT US',contents:{content_1:'contact us',content_2:'about vogue'}},
	// 	{title:'SERVICE',contents:{content_1:'payment methods',content_2:'track order'}},
	// 	{title:'POLICY',contents:{content_1:'privacy policy',content_2:'terms & condition'}},
	// 	{title:'FOLLOW US',contents:{content_1:'Facebook',content_2:'Instagram'}},
	// ],
	left_nav:{
		home:'主页',
		news:'news',
		collections:'collections',
		shop:'shop'
	},
	brandsArr:[
				{name:'clot',src:'../static/images/clot.jpg'},
				{name:'madness',src:'../static/images/madness.jpg'},
				{name:'bape',src:'../static/images/bape.jpg'},
				{name:'assc',src:'../static/images/assc.jpeg'},

	],
	clotIntro:{
			name:'clot',
			time:'2003年6月',
			person:'陈冠希',
			story:"EDISON陈冠希2003年创办了自己的服装品牌CLOT，在上海,北京,香港等地开有Clot潮流店铺：ACU、JUICE，努力成为中国第一潮牌!EDISON近两年创办了自己的服装品牌CLOT,并自己参与服装的设计、用料等 各个方面,成为中国第一潮牌,并在世界上都有一定的影力.CLOT是一个LIFESTYLE的公司，创作服装，包括CLOT品牌服装以及在香港的 JUICE店铺、策划PARTY、帮助香港一些公司做consultant，例如NIKE、PEPSI…、更包括CLOT自己的音乐!现成员包括：陈冠 希、MC仁、陈奂仁、DJ Tommy、厨房仔、恭硕良等一起，CLOT是一个FAMILY，是一个不可分开的家庭,而他的店铺JUICE也成为香港游客的一旅游胜地!CLOT也经常会与一些其他大品牌生产合作产品,像LEVI'S,NIKE,PEPSI等品牌!",
			shop:'ACU、JUICE',
			src:'../static/images/clot.jpg'
	},
	madnessIntro:{
			name:'madness',
			time:'2003年6月',
			person:'余文乐',
			story:"EDISON陈冠希2003年创办了自己的服装品牌CLOT，在上海,北京,香港等地开有Clot潮流店铺：ACU、JUICE，努力成为中国第一潮牌!EDISON近两年创办了自己的服装品牌CLOT,并自己参与服装的设计、用料等 各个方面,成为中国第一潮牌,并在世界上都有一定的影力.CLOT是一个LIFESTYLE的公司，创作服装，包括CLOT品牌服装以及在香港的 JUICE店铺、策划PARTY、帮助香港一些公司做consultant，例如NIKE、PEPSI…、更包括CLOT自己的音乐!现成员包括：陈冠 希、MC仁、陈奂仁、DJ Tommy、厨房仔、恭硕良等一起，CLOT是一个FAMILY，是一个不可分开的家庭,而他的店铺JUICE也成为香港游客的一旅游胜地!CLOT也经常会与一些其他大品牌生产合作产品,像LEVI'S,NIKE,PEPSI等品牌!",
			shop:'ACU、JUICE',
			src:'../static/images/madness.jpg'
	},
	asscIntro:{
			name:'assc',
			time:'2003年6月',
			person:'Neek Lurk',
			story:"EDISON陈冠希2003年创办了自己的服装品牌CLOT，在上海,北京,香港等地开有Clot潮流店铺：ACU、JUICE，努力成为中国第一潮牌!EDISON近两年创办了自己的服装品牌CLOT,并自己参与服装的设计、用料等 各个方面,成为中国第一潮牌,并在世界上都有一定的影力.CLOT是一个LIFESTYLE的公司，创作服装，包括CLOT品牌服装以及在香港的 JUICE店铺、策划PARTY、帮助香港一些公司做consultant，例如NIKE、PEPSI…、更包括CLOT自己的音乐!现成员包括：陈冠 希、MC仁、陈奂仁、DJ Tommy、厨房仔、恭硕良等一起，CLOT是一个FAMILY，是一个不可分开的家庭,而他的店铺JUICE也成为香港游客的一旅游胜地!CLOT也经常会与一些其他大品牌生产合作产品,像LEVI'S,NIKE,PEPSI等品牌!",
			shop:'ACU、JUICE',
			src:'../static/images/assc.jpeg'
	},
	bapeIntro:{
			name:'bape',
			time:'2003年6月',
			person:'NIGO',
			story:"EDISON陈冠希2003年创办了自己的服装品牌CLOT，在上海,北京,香港等地开有Clot潮流店铺：ACU、JUICE，努力成为中国第一潮牌!EDISON近两年创办了自己的服装品牌CLOT,并自己参与服装的设计、用料等 各个方面,成为中国第一潮牌,并在世界上都有一定的影力.CLOT是一个LIFESTYLE的公司，创作服装，包括CLOT品牌服装以及在香港的 JUICE店铺、策划PARTY、帮助香港一些公司做consultant，例如NIKE、PEPSI…、更包括CLOT自己的音乐!现成员包括：陈冠 希、MC仁、陈奂仁、DJ Tommy、厨房仔、恭硕良等一起，CLOT是一个FAMILY，是一个不可分开的家庭,而他的店铺JUICE也成为香港游客的一旅游胜地!CLOT也经常会与一些其他大品牌生产合作产品,像LEVI'S,NIKE,PEPSI等品牌!",
			shop:'ACU、JUICE',
			src:'../static/images/bape.jpg'
	},
	nowbrand:null,
	news:[
		{
			src:'../static/images/n1.jpg',
			title:'王嘉尔、陈伟霆、华晨宇…2020年，爱豆们都在推潮牌',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n2.jpg',
			title:'王俊凯代替吴亦凡成新代言人，能挽救香港潮牌I.T.吗?',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n3.jpg',
			title:'深度 | Supreme 如何成为年轻人的“欲望制造机” ？',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n4.jpg',
			title:'Justin Bieber个人服装潮牌成为年度时尚新品牌',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n5.jpg',
			title:'优衣库9月14日正式发售2020秋冬新款',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n6.jpg',
			title:'Supreme2020秋冬系列完整亮相了 看看本季有哪些重点款',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n7.jpg',
			title:'你还在直播间购物吗？南京一售假潮牌公司已被警方捕获 涉案2亿元',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n8.jpg',
			title:'潮牌有多火，老品牌就有多急',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n9.jpg',
			title:'老凤祥，它才是中国第一个走向世界的潮牌',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n10.jpg',
			title:'潮牌折扣集合店大爆发，受年轻人喜爱的轻奢潮牌服装回暖',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n11.png',
			title:'全球服饰潮牌KENZO创始人高田贤三因新冠去世',
			time:'2020/11/5'
		},
		{
			src:'../static/images/n12.jpg',
			title:'国潮元年到来，原创潮牌HEA以龙狮文创+潮流服饰突围潮...',
			time:'2020/11/5'
		},
	],
	goods:[
	//商品信息
		{
			src:'../static/images/s1.jpg',
			title:'SUPERTOFU(SPTF)新品AW20重磅厚实杏色宽松灯芯绒阔身西装夹克',
			shopsSrc:'../static/images/shops_1.jpg',
			shopsName:'jenry',
			price:679,
			isLike:true,
			likes:10,
			flag:false,
			num:1,
			description:'版型选择中长款MA1进行改良 合身塑形 •使用杜邦梭织面料，抗风防水耐磨 •内里填充300克重鸭绒，恒温保暖 •胸口定制四个联名胸章 玩味十足 •DIE WELLE 延续秋冬沙漠主题将SAHARA之眼至于肩覆水，并将石莲花与TEAMAGE标志性玫瑰花置于左臂与面料质感形成强烈对比',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},
		{
			src:'../static/images/s2.jpg',
			title:'SUPERTOFU(SPTF)新品AW20复古灰蓝色植绒绣图案花灰圆领加绒卫衣',
			shopsSrc:'../static/images/shops_2.jpg',
			shopsName:'买物教室',
			price:499,
			isLike:true,
			likes:5,
			flag:false,
			num:1,
			description:'大家都喜欢吃披萨，当然喵星人也不例外，萌猫躲在披萨里头仿佛在向主人抗议，简直萌化了。这件Stay gold 三色贪吃猫披萨卫衣正面采用刺绣工艺，完美呈现披萨拉丝效果，而且采用10支350克加绒面料，兼具舒适性和保暖性。',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},
		{
			src:'../static/images/s3.jpg',
			title:'SUPERTOFU(SPTF)AW20新品多口袋厚实杏色棕色灯芯绒猎装夹克外套',
			shopsSrc:'../static/images/shops_1.jpg',
			price:380,
			shopsName:'jenry',
			isLike:true,
			likes:5,
			flag:false,
			num:1,
			description:'外星人系列。春秋教练夹克，白蓝黑红四色任意挑选。胸前的外星人设计，更显年轻时尚，街头范十足。冲锋衣面料，防水透气，穿着舒适，相比同类的冲锋衣夹克，这款性价比更高。推荐入手。',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},
		{
			src:'../static/images/s4.jpg',
			title:'GRAF原创品牌羊毛红格子皮袖刺绣大logo棒球开衫秋冬厚重夹克外套',
			shopsSrc:'../static/images/shops_3.jpg',
			shopsName:'QW',
			price:119,
			isLike:true,
			likes:10,
			flag:false,
			num:1,
			description:'版型选择中长款MA1进行改良 合身塑形 •使用杜邦梭织面料，抗风防水耐磨 •内里填充300克重鸭绒，恒温保暖 •胸口定制四个联名胸章 玩味十足 •DIE WELLE 延续秋冬沙漠主题将SAHARA之眼至于肩覆水，并将石莲花与TEAMAGE标志性玫瑰花置于左臂与面料质感形成强烈对比',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},
		{
			src:'../static/images/s5.jpg',
			title:'NOTHOMME潮牌学院风复古纯色翻领呢料短大衣外厚套藏青色男装秋冬',
			shopsSrc:'../static/images/shops_2.jpg',
			shopsName:'QW',
			price:698,
			isLike:true,
			likes:5,
			flag:false,
			num:1,
			description:'大家都喜欢吃披萨，当然喵星人也不例外，萌猫躲在披萨里头仿佛在向主人抗议，简直萌化了。这件Stay gold 三色贪吃猫披萨卫衣正面采用刺绣工艺，完美呈现披萨拉丝效果，而且采用10支350克加绒面料，兼具舒适性和保暖性。',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},
		{
			src:'../static/images/s6.jpg',
			title:'NOTHOMME日系潮牌工装宽松束脚裤男款青年多口袋小脚休闲长裤街头',
			shopsSrc:'../static/images/shops_1.jpg',
			price:428,
			shopsName:'jenry',
			isLike:true,
			likes:5,
			flag:false,
			num:1,
			description:'外星人系列。春秋教练夹克，白蓝黑红四色任意挑选。胸前的外星人设计，更显年轻时尚，街头范十足。冲锋衣面料，防水透气，穿着舒适，相比同类的冲锋衣夹克，这款性价比更高。推荐入手。',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},
		{
			src:'../static/images/s7.jpg',
			title:'NOTHOMME日系潮牌工装束脚卫裤男情侣款宽松针织运动慢跑休闲长裤',
			shopsSrc:'../static/images/shops_1.jpg',
			shopsName:'jenry',
			price:679,
			isLike:true,
			likes:10,
			flag:false,
			num:1,
			description:'版型选择中长款MA1进行改良 合身塑形 •使用杜邦梭织面料，抗风防水耐磨 •内里填充300克重鸭绒，恒温保暖 •胸口定制四个联名胸章 玩味十足 •DIE WELLE 延续秋冬沙漠主题将SAHARA之眼至于肩覆水，并将石莲花与TEAMAGE标志性玫瑰花置于左臂与面料质感形成强烈对比',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},
		{
			src:'../static/images/s8.jpg',
			title:'NOTHOMME2020日系潮牌工装连帽羽绒服男士情侣装冬季保暖加厚外套',
			shopsSrc:'../static/images/shops_2.jpg',
			shopsName:'买物教室',
			price:199,
			isLike:true,
			likes:5,
			flag:false,
			num:1,
			description:'大家都喜欢吃披萨，当然喵星人也不例外，萌猫躲在披萨里头仿佛在向主人抗议，简直萌化了。这件Stay gold 三色贪吃猫披萨卫衣正面采用刺绣工艺，完美呈现披萨拉丝效果，而且采用10支350克加绒面料，兼具舒适性和保暖性。',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},
		{
			src:'../static/images/s9.jpg',
			title:'NOTHOMME潮牌新款西装领中长款宽松毛呢大衣男情侣冬季厚外套风衣',
			shopsSrc:'../static/images/shops_1.jpg',
			price:199,
			shopsName:'jenry',
			isLike:true,
			likes:5,
			flag:false,
			num:1,
			description:'外星人系列。春秋教练夹克，白蓝黑红四色任意挑选。胸前的外星人设计，更显年轻时尚，街头范十足。冲锋衣面料，防水透气，穿着舒适，相比同类的冲锋衣夹克，这款性价比更高。推荐入手。',
			sizes:['S','M','L','XL'],
			size:'',
			colors:['黑色','白色','红色','灰色'],
			color:'',
			completed:false//用来检测购物车中是否选中
		},

	],
	selectedItem:{},
	sessionSelectedItem:{},
	cart:[]
}
const mutations={
	CHANGE_HW(state,obj){
		state.clientwidth=obj.w;
		state.clientheight=obj.h;
	},
	CHANGE_SHOW(state,type){
		state.show=type
	},
	CHANGE_NOWBRAND(state,type){
		state.nowbrand=type+'Intro'
	},
	CHANGE_LIKE(state,index){
		state.goods[index].isLike=!state.goods[index].isLike;
		if(!state.goods[index].isLike){
			state.goods[index].likes+=1
		}else{
			state.goods[index].likes-=1
		}
	},
	CHANGE_FLAG_TURE(state,index){
		state.goods[index].flag=true
	},
	CHANGE_FLAG_FALSE(state,index){
		state.goods[index].flag=false
	},
	CHANGE_SELECTED_ITEM(state,index){
		state.selectedItem=mutations.clone(state.goods[index]);
		var temp=mutations.clone(state.selectedItem);
		sessionStorage.setItem('storageItem',JSON.stringify(temp));
	},
	CHANGE_SIZE(state,index){
		state.selectedItem.size=state.selectedItem.sizes[index]
	},
	CHANGE_COLOR(state,num){
		state.selectedItem.color=state.selectedItem.colors[num]
	},
	//选中的商品数量增减
	CHANGE_NUM_SUB(state,index){
		if(typeof(index)!='number'){
			state.selectedItem.num-=1
		}else{
			state.cart[index].num-=1
		}

	},
	CHANGE_NUM_ADD(state,index){
		if(typeof(index)!='number'){
			state.selectedItem.num+=1
		}else{
			state.cart[index].num+=1
		}
	},

	ADD_TO_CART(state){
		var cart=state.cart;
		var thing=mutations.clone(state.selectedItem);
		//查看购物车是否已经有相同的商品，信息都一样

		if(!cart.length){
			cart.push(thing)
		}else{
			var flag=cart.some(function(e){
				return e.color==thing.color&&e.size==thing.size&&e.src==thing.src
			})
			try{
				if(!flag){
					cart.push(thing);
					throw new Error("can't find")
				}
				cart.forEach(function(e,index){
					if(e.color==thing.color&&e.size==thing.size&&e.src==thing.src){
						cart[index].num+=thing.num;
						foreach.break=new Error("StopIteration");
					}
				})
			}catch(e){
				//用于跳出循环
			}

		}
		state.selectedItem={};
	},
	//删除商品
	REMOVE(state,index){
		state.cart.splice(index,1)
	},
	//js复制对象
	clone(myObj){
	  if(typeof(myObj) != 'object') return myObj;
	  if(myObj == null) return myObj;

	  var myNewObj = new Object();

	  for(var i in myObj)
	    myNewObj[i] = mutations.clone(myObj[i]);

	  return myNewObj;
	},
	CHANGE_LOGINWAY(state,type){
		state.loginway=type
	}
}
const actions={
	change_hw({commit},obj){
		commit('CHANGE_HW',obj)
	},
	changeShow({commit},type){
		commit('CHANGE_SHOW',type)
	},
	changeNowbrand({commit},type){
		commit('CHANGE_NOWBRAND',type)
	},
	changeLike({commit},index){
		commit('CHANGE_LIKE',index)
	},
	changeFlagTrue({commit},index){
		commit('CHANGE_FLAG_TURE',index)
	},
	changeFlagFalse({commit},index){
		commit('CHANGE_FLAG_FALSE',index)
	},
	changeSelectedItem({commit},index){
		commit('CHANGE_SELECTED_ITEM',index)
	},
	changeSize({commit},index){
		commit('CHANGE_SIZE',index)
	},
	changeColor({commit},num){
		commit('CHANGE_COLOR',num)
	},
	//选中的商品数量增减，包括购物车和单个商品
	changeNumSub({commit},index){
		commit('CHANGE_NUM_SUB',index)
	},
	changeNumAdd({commit},index){
		commit('CHANGE_NUM_ADD',index)
	},
	addToCart({commit}){
		commit('ADD_TO_CART')
	},
	remove({commit},index){
		commit('REMOVE',index)
	},
	//改变登录方式
	changeLoginway({commit},type){
		commit('CHANGE_LOGINWAY',type)
	}
}
const getters={
	getHW:function(state){
		return {
			h:state.clientheight,
			w:state.clientwidth
		}
	},
	getBrands:function(state){
		return state.brandsArr
	},
	getLeft_nav:function(state){
		return state.left_nav
	},
	getShow:function(state){
		return state.show
	},
	getFootItems:function(state){
		return state.footItems
	},
	//返回点击的品牌
	getIntro:function(state){
		return state[state.nowbrand];
	},
	getNews:function(state){
		return state.news;
	},
	getGoods:function(state){
		return state.goods
	},
	getSelectedItem:function(state){
		return state.selectedItem
	},
	getCart:function(state){
		return state.cart
	},
	getLoginway:function(state){
		return state.loginway
	}
}
export default new Vuex.Store({
	state,
	mutations,
	actions,
	getters
})
